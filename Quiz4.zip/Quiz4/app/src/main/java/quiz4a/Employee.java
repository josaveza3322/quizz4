package quiz4a;


// (1.1) เป็นคลาส employee ตั้งให้ Name เป็น String ตั้งให้พนักงานเป็น int มีเมธอดเพื้่อเรียกดู เลขบัตรพนักงาน ชื่อ และเงินเดือน
public class Employee {
    private int employeeId;
    private String name;
    private double salary;

    // (1.2) เป็นการสร้าง object ตั้งให้ ้ เลขบัตรพนักงานไม่ให้ซ้ำกัน และ ตั้งชื่อให้เป็นชื่อพนักงาน และ ตั้งเงินเดือนให้พนักงานมากกว่า 0
    public Employee(int employeeId, String name, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.salary = (salary > 0) ? salary : 0;
    }

    // (1.3) เป็นเมธอดเพื่อคำนวน เงินเดือน และรีเทรินเป็น เงินเดือน 
    public double calculateSalary() {
        return salary;
    }

    // (1.4) เป็นเมธอดเพื่อเรียก เลขบัตรพนักงาน และ รีเทรินเป็น เลขบัตรพนักงาน
    public int getEmployeeId() {
        return employeeId;
    }

    // (1.5)  เป็นเมธอดเพื่อเรียก ชื่อพนักงาน และ รีเทรินเป็น ชื่อพนักงาน
    public String getName() {
        return name;
    }
}