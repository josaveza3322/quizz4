package quiz4a;

// 2.1 เปฺ็นคลาสสืบทอด Manager สืบทอดมาจาก class employee และตั้งให้ Depratment เป็น String และ ตั้งให้ bonus เป็น double เพื่มมา
public class Manager extends Employee {
    private String department;
    private double bonus;

    
    // 2.2 เป็นการสร้าง ออบเจ็ค จาก Manager แล้ว
    public Manager(int employeeId, String name, double salary, String department, double bonus) {
        super(employeeId, name, salary);
        this.department = department;
        this.bonus = 20;
    }

    // 2.3 ให้แสดงรายละเอียดของ employeeid,name,salary,department,bonus
    public void displayDetails() {
        String[] details = {
            "Employee ID: " + getEmployeeId(),
            "Name: " + getName(),
            "Salary: " + calculateSalary(),
            "Department: " + department,
            "Bonus: " + "20%"
        };
        for (String detail : details) {
            System.out.println(detail);
        }
    }

    //2.4 ให้แสดงรายละเอียดเเบบเงื่อนไขแบบ ถ้าเป็น FULL แสดงทั้งหมด และถ้า แต่ถ้าให้แสดงเฉพาะรายละเอียด employeeid,name 
    public void displayDetails(String condition) {
        if ("full".equalsIgnoreCase(condition)) {

            String[] details = {
                "Employee ID: " + getEmployeeId(),
                "Name: " + getName(),
                "Salary: " + calculateSalary(),
                "Department: " + department,
                "Bonus: " + bonus
            };
            for (String detail : details) {
                System.out.println(detail);
            }
        } else {

            String[] details = {
                "Employee ID: " + getEmployeeId(),
                "Name: " + getName()
            };
            for (String detail : details) {
                System.out.println(detail);
            }
        }
    }
}
